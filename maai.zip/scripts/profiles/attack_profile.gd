class_name AttackProfile
extends Resource

enum ParryInteractionType {
	STANDARD,
	UNPARRYABLE
}

enum UnparryableType {
	NONE,
	THRUST,
	SWEEP
}

enum MovementType {
	PHYSICS,
	PATH_TARGET
}

@export_group("Phases")
@export var startup_duration: float = 0.3
@export var active_duration: float = 0.2
@export var block_recoil_duration: float = 0.35
@export var recovery_duration: float = 0.2
@export var link_duration: float = 0.6

@export_group("Presentation")
@export var animation_name: StringName
@export var startup_sfx: AudioStream
@export var active_sfx: AudioStream
@export var recovery_sfx: AudioStream
@export var impact_sfx: AudioStream

@export_group("Hitbox")
@export var hitbox_size: Vector2 = Vector2(90, 64)
@export var hitbox_position: Vector2 = Vector2(40, 0)

@export_group("Mechanics")
@export var damage: float = 1.0
@export var stamina_cost: float = 0.0
@export var focus_cost: int = 0
@export var focus_gain_on_hit: int = 0
@export var stamina_damage: float = 10.0
@export var poise_impact_contribution: float = 10.0
@export var poise_momentum_gain: float = 0.0
@export var poise_momentum_duration: float = 1.5
@export var knockback_vector: Vector2 = Vector2(400, 0)
@export var defender_knockback_on_parry: float = 120.0
@export var parry_interaction: ParryInteractionType = ParryInteractionType.STANDARD
@export var unparryable_type: UnparryableType = UnparryableType.NONE

@export_group("Movement")
@export var movement_type: MovementType = MovementType.PHYSICS
@export var startup_movement_velocity: Vector2 = Vector2.ZERO
@export var active_movement_velocity: Vector2 = Vector2.ZERO
@export var recovery_movement_velocity: Vector2 = Vector2.ZERO
@export var link_movement_velocity: Vector2 = Vector2.ZERO

@export_group("Poise Contributions per Phase (Defensivo)")
@export var startup_poise_shield: float = 10.0
@export var active_poise_shield: float = 10.0
@export var recovery_poise_shield: float = 300.0
