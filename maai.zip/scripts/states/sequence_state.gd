class_name SequenceState
extends State

enum LinkPhases { ACTIVE, LINK, FINISHED }
var _current_phase: LinkPhases = LinkPhases.FINISHED
var _time_left_in_link: float = 0.0

var _attack_executor: AttackExecutor
var _cost_validator: ActionCostValidator
var _is_initialized: bool = false

var _skill_sequence: ActionSequence
var _current_profile: AttackProfile

func enter(args: Dictionary = {}):
	if not _is_initialized:
		_attack_executor = owner_node.find_child("AttackExecutor")
		_cost_validator = owner_node.find_child("ActionCostValidator")
		assert(_attack_executor != null, "SequenceState: Nó 'AttackExecutor' não encontrado como irmão.")
		assert(_cost_validator != null, "SequenceState: Nó 'ActionCostValidator' não encontrado como irmão.")
		_is_initialized = true
		
	_attack_executor.finished.connect(_on_attack_finished)
	_attack_executor.attack_phase_changed.connect(_on_phase_changed)

	_skill_sequence = args.get("sequence_context")

	if not _skill_sequence:
		state_machine.on_current_state_finished()
		return
	
	owner_node.facing_locked = true
	_current_phase = LinkPhases.ACTIVE
	_execute_next_attack()

func exit():
	if _attack_executor:
		if _attack_executor.is_connected("finished", Callable(self, "_on_attack_finished")):
			_attack_executor.finished.disconnect(_on_attack_finished)
		if _attack_executor.is_connected("attack_phase_changed", Callable(self, "_on_phase_changed")):
			_attack_executor.attack_phase_changed.disconnect(_on_phase_changed)
		_attack_executor.stop()
		
	owner_node.facing_locked = false
	_current_profile = null
	_current_phase = LinkPhases.FINISHED

func process_physics(delta: float, _walk_direction: float, _is_running: bool) -> Vector2:
	var calculated_velocity = Vector2.ZERO

	if _current_phase == LinkPhases.LINK:
		_time_left_in_link -= delta
		if _time_left_in_link <= 0.0:
			state_machine.on_current_state_finished()
			return physics_component.apply_gravity(Vector2.ZERO, delta)
	elif _attack_executor and _current_profile:
		if _current_profile.movement_type == AttackProfile.MovementType.PATH_TARGET:
			if path_follower_component and path_follower_component.is_active():
				calculated_velocity = path_follower_component.calculate_target_velocity(delta)
		else: # PHYSICS
			calculated_velocity = _attack_executor.get_physics_movement_velocity()

	var final_velocity = physics_component.apply_gravity(calculated_velocity, delta)
	return final_velocity

func handle_attack_input(_profile: AttackProfile) -> InputHandlerResult:
	if _current_phase == LinkPhases.LINK:
		return InputHandlerResult.new(InputHandlerResult.Status.ACCEPTED)
	return InputHandlerResult.new(InputHandlerResult.Status.REJECTED)

func handle_parry_input(_profile: ParryProfile) -> InputHandlerResult:
	if _current_phase == LinkPhases.LINK:
		return InputHandlerResult.new(InputHandlerResult.Status.ACCEPTED)
	return InputHandlerResult.new(InputHandlerResult.Status.REJECTED)

func handle_dodge_input(_direction: Vector2, _profile: DodgeProfile) -> InputHandlerResult:
	if _current_phase == LinkPhases.LINK:
		return InputHandlerResult.new(InputHandlerResult.Status.ACCEPTED)
	return InputHandlerResult.new(InputHandlerResult.Status.REJECTED)

func _on_attack_finished():
	_execute_next_attack()

func _execute_next_attack():
	if _current_phase != LinkPhases.ACTIVE:
		return

	var next_profile = _skill_sequence.get_next_profile()

	if next_profile:
		if _cost_validator.try_pay_costs(next_profile):
			_current_profile = next_profile
			_attack_executor.execute(_current_profile)
		else:
			_current_phase = LinkPhases.FINISHED
			state_machine.on_current_state_finished()
	else:
		if state_machine.buffer_component.has_buffer():
			_current_phase = LinkPhases.FINISHED
			state_machine.on_current_state_finished()
			return
		
		if not _current_profile:
			_current_phase = LinkPhases.FINISHED
			state_machine.on_current_state_finished()
			return
		
		_current_phase = LinkPhases.LINK
		_time_left_in_link = _current_profile.link_duration
		
func resolve_contact(context: ContactContext) -> ContactResult:
	var executor_phase = _attack_executor.get_current_phase_name()

	if executor_phase == "RECOVERY" or _current_phase == LinkPhases.LINK:
		return _resolve_default_contact(context)
	else:
		if context.attack_profile.parry_interaction == AttackProfile.ParryInteractionType.UNPARRYABLE:
			context.defender_health_comp.take_damage(context.attack_profile.damage)
			var reason = { "outcome": "POISE_BROKEN", "knockback_vector": context.attack_profile.knockback_vector }
			state_machine.on_current_state_finished(reason)
			
			var unparryable_result = ContactResult.new()
			unparryable_result.attacker_node = context.attacker_node
			unparryable_result.defender_node = context.defender_node
			unparryable_result.attack_profile = context.attack_profile
			unparryable_result.defender_outcome = ContactResult.DefenderOutcome.POISE_BROKEN
			unparryable_result.attacker_outcome = ContactResult.AttackerOutcome.NONE
			return unparryable_result

		var result = ContactResult.new()
		result.attacker_node = context.attacker_node
		result.defender_node = context.defender_node
		result.attack_profile = context.attack_profile
		
		var my_shield_poise = context.defender_poise_comp.get_effective_shield_poise()
		var attacker_sword_poise = context.attacker_offensive_poise
		
		context.defender_health_comp.take_damage(context.attack_profile.damage)
		
		if attacker_sword_poise >= my_shield_poise:
			var reason = { "outcome": "POISE_BROKEN", "knockback_vector": context.attack_profile.knockback_vector }
			state_machine.on_current_state_finished(reason)
			
			result.attacker_outcome = ContactResult.AttackerOutcome.NONE
			result.defender_outcome = ContactResult.DefenderOutcome.POISE_BROKEN
		else:
			result.attacker_outcome = ContactResult.AttackerOutcome.TRADE_LOST
			result.defender_outcome = ContactResult.DefenderOutcome.HIT

		return result

func get_poise_shield_contribution() -> float:
	if not _current_profile:
		return 0.0

	if _current_phase == LinkPhases.LINK:
		return _current_profile.recovery_poise_shield

	var executor_phase = _attack_executor.get_current_phase_name()
	match executor_phase:
		"STARTUP":
			return _current_profile.startup_poise_shield
		"ACTIVE":
			return _current_profile.active_poise_shield
		"RECOVERY":
			return _current_profile.recovery_poise_shield
		_:
			return _current_profile.recovery_poise_shield

func get_poise_impact_contribution() -> float:
	if not _current_profile: return 0.0
	return _current_profile.poise_impact_contribution

func get_attack_profile() -> AttackProfile:
	return _current_profile

func allow_reentry() -> bool:
	return true

func _on_phase_changed(phase_data: Dictionary):
	state_machine.emit_phase_change(phase_data)
